// Add event listeners to the buttons
const sampleMockTestBtn = document.querySelector('.buttons a:first-child');
const freeStudyMaterialBtn = document.querySelector('.buttons a:last-child');

sampleMockTestBtn.addEventListener('click', () => {
  // Redirect to the sample mock test page
  window.location.href = 'sample-mock-test.html';
});

freeStudyMaterialBtn.addEventListener('click', () => {
  // Redirect to the free study material page
  window.location.href = 'free-study-material.html';
});

// Toggle mobile menu
const menuToggle = document.querySelector('.menu-toggle');
const navMenu = document.querySelector('nav ul');

menuToggle.addEventListener('click', () => {
  menuToggle.classList.toggle('active');
  navMenu.classList.toggle('active');
});
